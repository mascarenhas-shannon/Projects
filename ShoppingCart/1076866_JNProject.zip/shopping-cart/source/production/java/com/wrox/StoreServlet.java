package com.wrox;

import java.io.IOException;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

@WebServlet(
        name = "storeServlet",
        urlPatterns = "/shop"
)
public class StoreServlet extends HttpServlet
{
	final static Logger logger = Logger.getLogger(StoreServlet.class);
    private final Map<Integer, String> products = new Hashtable<>();
    public int sandpaperPrice = 10;
    public int nailsPrice = 15;
    public int gluePrice = 20;
    public int paintPrice = 40;
    public int tapePrice = 25;
    public int totalPrice = 0;
    

    public StoreServlet()
    {
        this.products.put(1, "Sandpaper");
        this.products.put(2, "Nails");
        this.products.put(3, "Glue");
        this.products.put(4, "Paint");
        this.products.put(5, "Tape");
        
        for (Map.Entry<Integer,String> entry : this.products.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			logger.info("Product Id:" + key + " Product Name:" + value);
		} 
    }

    
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        String action = request.getParameter("action");
        if(action == null)
            action = "browse";

        switch(action)
        {
            case "addToCart":
                this.addToCart(request, response);
                break;

            case "emptyCart":
                this.emptyCart(request, response);
                break;

            case "viewCart":
                this.viewCart(request, response);
                break;

            case "browse":
            default:
                this.browse(request, response);
                break;
        }
    }

    private void addToCart(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException
    {
    	
    	logger.info("Adding to the cart");
        int productId;
        try
        {
            productId = Integer.parseInt(request.getParameter("productId"));
            logger.info("Product Id : " + productId + " Product Name : "+ products.get(productId) );
            
            
        }
        catch(Exception e)
        {
            response.sendRedirect("shop");
            return;
        }

        HttpSession session = request.getSession();
        if(session.getAttribute("cart") == null)
            session.setAttribute("cart", new Hashtable<Integer, Integer>());
            

        @SuppressWarnings("unchecked")
        Map<Integer, Integer> cart =
                (Map<Integer, Integer>)session.getAttribute("cart");
        
        if(session.getAttribute("prices") == null)
            session.setAttribute("prices", new Hashtable<Integer, Integer>());
            
        @SuppressWarnings("unchecked")
        Map<Integer, Integer> prices =
                (Map<Integer, Integer>)session.getAttribute("prices");
        if(!cart.containsKey(productId))
            cart.put(productId, 0);      
        
        
        switch(productId)
        {
            case 1:
                logger.info("Sandpaper Quantity: "+ (cart.get(productId) + 1) + " ");
                prices.put(productId, (cart.get(productId) + 1) * sandpaperPrice);

            	logger.info("Prices Map values after adding Sandpaper");
            		for (Map.Entry<Integer,Integer> entry : prices.entrySet()) {
            				int key = entry.getKey();
            				int value = entry.getValue();
            				logger.info("Product Id : " + key + " Price Value : " + value);
            			}                
                break;

            case 2:
                logger.info("Nails Quantity : " + (cart.get(productId) + 1) + " ");
                prices.put(productId, (cart.get(productId) + 1) * nailsPrice);
                logger.info("Prices Map values after adding Nails");
        		for (Map.Entry<Integer,Integer> entry : prices.entrySet()) {
        				int key = entry.getKey();
        				int value = entry.getValue();
        				logger.info("Product Id : " + key + " Price Value : " + value);
        			} 

                break;

            case 3:
                logger.info("Glue Quantity: " + (cart.get(productId) + 1) + " ");
                prices.put(productId, (cart.get(productId) + 1) * gluePrice);
                logger.info("Prices Map values after adding Glue");
        		for (Map.Entry<Integer,Integer> entry : prices.entrySet()) {
        				int key = entry.getKey();
        				int value = entry.getValue();
        				logger.info("Product Id : " + key + " Price Value : " + value);
        			} 
             	
                break;

            case 4:
                logger.info("Paint Quantity: "+ (cart.get(productId) + 1) + " " );
                prices.put(productId, (cart.get(productId) + 1) * paintPrice);
                logger.info("Prices Map values after adding Paint");
        		for (Map.Entry<Integer,Integer> entry : prices.entrySet()) {
        				int key = entry.getKey();
        				int value = entry.getValue();
        				logger.info("Product Id : " + key + " Price Value :" + value);
        			} 
                break;
                
               
            case 5:
                logger.info("Tape Quantity: "+ (cart.get(productId) + 1) + " ");
                prices.put(productId, (cart.get(productId) + 1) * tapePrice);
                logger.info("Prices Map values after adding Tape");
        		for (Map.Entry<Integer,Integer> entry : prices.entrySet()) {
        				int key = entry.getKey();
        				int value = entry.getValue();
        				logger.info("Product Id : " + key + " Price Value : " + value);
        			} 
                break;
        }
        
        
        cart.put(productId, cart.get(productId) + 1);

        logger.info("Cart Map values");
		for (Map.Entry<Integer,Integer> entry : cart.entrySet()) {
				int key = entry.getKey();
				int value = entry.getValue();
				logger.info("Product Id : " + key + " Cart Value(Quantity): " + value);
			}
    	response.sendRedirect("shop?action=viewCart");
    }

    private void emptyCart(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException
    {
        logger.info("Empty the Cart");

    	totalPrice=0;
        request.getSession().removeAttribute("cart");
        response.sendRedirect("shop?action=viewCart");
    }

    private void viewCart(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        logger.info("View Cart");

    	request.setAttribute("total", totalPrice);
        request.setAttribute("products", this.products);
        
        request.getRequestDispatcher("/WEB-INF/jsp/view/viewCart.jsp")
                .forward(request, response);
    }

    private void browse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        logger.info("Browse Cart");

        request.setAttribute("products", this.products);
        request.getRequestDispatcher("/WEB-INF/jsp/view/browse.jsp")
               .forward(request, response);
    }
}
